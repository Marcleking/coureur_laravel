/** Automatically generated file. DO NOT MODIFY */
package com.dinfogarneau.cours624.demo.liste_dynamique;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}